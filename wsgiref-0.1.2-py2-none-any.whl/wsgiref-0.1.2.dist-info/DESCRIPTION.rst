This is a standalone release of the ``wsgiref`` library to be included in
Python 2.5.  For the standalone version's documentation, see:

HTML
  http://peak.telecommunity.com/wsgiref_docs/

PDF
  http://peak.telecommunity.com/wsgiref.pdf




