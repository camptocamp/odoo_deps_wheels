Description
-----------

Parses iCalendar and vCard files into Python data structures, decoding the relevant encodings. Also serializes vobject data structures to iCalendar, vCard, or (expirementally) hCalendar unicode strings.

Requirements
------------

Requires python 2.4 or later, dateutil (http://labix.org/python-dateutil) 1.1 or later.

Recent changes
--------------

   * Allow unicode names for TZIDs
   * Worked around Lotus Notes use of underscores in names by just silently replacing
     with dashes
   * When allowing quoted-printable data, honor CHARSET for each line, defaulting to 
     iso-8859-1
   * Simplified directory layout, unit tests are now available via setup.py test
   * Added VAVAILABILITY support
   * Improved wrapping of unicode lines, serialize encodes unicode as utf-8 by default

For older changes, see 
   * http://vobject.skyhouseconsulting.com/history.html or 
   * http://websvn.osafoundation.org/listing.php?repname=vobject&path=/trunk/


