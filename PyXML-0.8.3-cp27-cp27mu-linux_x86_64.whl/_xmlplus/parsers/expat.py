"""Interface to the Expat non-validating XML parser."""
__version__ = '$Revision: 1.1 $'

from pyexpat import *
