Pychart is a Python library for creating high-quality
charts in Postscript, PDF, PNG, and SVG. 
It produces line plots, bar plots, range-fill plots, and pie
charts.

