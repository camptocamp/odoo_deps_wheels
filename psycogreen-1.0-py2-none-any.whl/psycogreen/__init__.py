"""Integration of psycopg2 with coroutine framework
"""

# Copyright (C) 2010-2012 Daniele Varrazzo <daniele.varrazzo@gmail.com>
# All rights reserved.  See COPYING file for details.


__version__ = '1.0'

